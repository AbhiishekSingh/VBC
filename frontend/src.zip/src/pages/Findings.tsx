/**
 * Step 3 — findings.
 *
 * The four tiles are the point of this screen, and the fourth is the one
 * that makes this product different from a generic KYC tool: NOT CHECKED
 * is given the same visual weight as passed, attention and adverse. It is
 * broken down by reason — skipped for a missing input, deselected by the
 * analyst, or not configured on the platform at all — because those three
 * mean very different things and none of them mean "clean".
 */

import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'

import { CHECKS, CHECK_GROUPS } from '@/catalog/generated'
import { Card, EmptyState, STATUS_EXPLANATION, StatusBadge, Tile } from '@/components/ui'
import type { PageProps } from '@/App'
import type { CheckStatus } from '@/types/domain'

const RAW_SAMPLE = (checkId: string, vendor: { cin: string | null; domain: string | null }) =>
  JSON.stringify(
    {
      _note:
        'In production this is the exact stored payload from vendor_checks.raw_response, ' +
        'so any historical score can be reconstructed from the bytes it was computed on.',
      checkId,
      request: { cin: vendor.cin, domain: vendor.domain },
    },
    null,
    2,
  )

export default function Findings({ vendor, setPrimary }: PageProps) {
  const navigate = useNavigate()
  const [open, setOpen] = useState<string | null>(null)

  const results = Object.values(vendor.checks)

  const counts = useMemo(() => {
    const by = (s: CheckStatus) => results.filter((r) => r.status === s).length
    const skippedInput = by('skipped_missing_input')
    const notApplicable = by('skip')
    const unavailable = by('unavailable')

    // Everything the analyst could have run but did not.
    const deselected = CHECKS.filter(
      (c) => c.state === 'active' && !c.admin && !vendor.selected.includes(c.id),
    ).length
    const unconfigured = CHECKS.filter((c) => c.state === 'not_configured').length

    return {
      pass: by('pass'),
      warn: by('warn'),
      fail: by('fail'),
      skippedInput,
      notApplicable,
      unavailable,
      deselected,
      unconfigured,
      notChecked: skippedInput + notApplicable + unavailable + deselected + unconfigured,
    }
  }, [results, vendor.selected])

  useEffect(() => {
    setPrimary(
      <button type="button" className="btn primary" onClick={() => navigate(`/vendor/${vendor.id}/manual`)}>
        Record manual entries →
      </button>,
    )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vendor.id])

  if (results.length === 0) {
    return (
      <EmptyState
        title="No checks have run yet"
        body="Select the checks this vendor warrants and run them. Findings, scoring and the report all build from what comes back."
        action={
          <button type="button" className="btn primary" onClick={() => navigate(`/vendor/${vendor.id}/select`)}>
            Choose what to check
          </button>
        }
      />
    )
  }

  return (
    <div className="stack">
      <div>
        <div className="kicker">Step 3 · Evidence</div>
        <h2 className="page-h">Findings</h2>
        <p className="page-sub">
          What each source returned, grouped by provider. Every result carries its raw payload,
          and what was <em>not</em> examined is shown alongside what was.
        </p>
      </div>

      <div className="grid-4">
        <Tile n={counts.pass} label="Passed" tone="pass" />
        <Tile n={counts.warn} label="Needs attention" tone="warn" />
        <Tile n={counts.fail} label="Adverse" tone="adverse" />
        <Tile
          n={counts.notChecked}
          label="Not checked"
          tone="unchecked"
          note={
            [
              counts.skippedInput && `${counts.skippedInput} missing input`,
              counts.notApplicable && `${counts.notApplicable} not applicable`,
              counts.unavailable && `${counts.unavailable} unavailable`,
              counts.deselected && `${counts.deselected} deselected`,
              counts.unconfigured && `${counts.unconfigured} not configured`,
            ]
              .filter(Boolean)
              .join(' · ') || undefined
          }
        />
      </div>

      <div className="callout k-info">
        <div className="callout-h">Nothing here is clearance on what was not examined</div>
        <p className="small muted">
          {counts.unconfigured} checks have no provider on this platform — including GST
          verification and all sanctions screening. {counts.deselected} further checks were
          available but not selected for this vendor. Both appear by name in the report.
        </p>
      </div>

      {CHECK_GROUPS.map((group) => {
        const rows = CHECKS.filter((c) => c.group === group.id && vendor.checks[c.id])
        if (!rows.length) return null

        return (
          <Card key={group.id} title={group.name} subtitle={group.source} tight>
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th>Check</th>
                    <th>Status</th>
                    <th>Result</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((check) => {
                    const result = vendor.checks[check.id]
                    const isOpen = open === check.id
                    return (
                      <>
                        <tr key={check.id}>
                          <td style={{ maxWidth: 210 }}>
                            <div style={{ fontWeight: 550 }}>{check.name}</div>
                            <div className="small mono muted">{check.endpoint}</div>
                          </td>
                          <td>
                            <StatusBadge status={result.status} />
                          </td>
                          <td>
                            <div style={{ fontWeight: 550 }}>{result.value || '—'}</div>
                            <div className="small muted">
                              {result.detail || STATUS_EXPLANATION[result.status]}
                            </div>
                          </td>
                          <td style={{ width: 1 }}>
                            <button
                              type="button"
                              className="btn sm ghost"
                              onClick={() => setOpen(isOpen ? null : check.id)}
                              aria-expanded={isOpen}
                            >
                              {isOpen ? 'Hide' : 'View'} API response
                            </button>
                          </td>
                        </tr>
                        {isOpen && (
                          <tr key={`${check.id}-raw`}>
                            <td colSpan={4} style={{ background: 'var(--surface-2)' }}>
                              <pre className="raw">{RAW_SAMPLE(check.id, vendor)}</pre>
                            </td>
                          </tr>
                        )}
                      </>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        )
      })}

      <Card title="Not examined" subtitle="Shown in full — a gap must never read as a clean result" tight>
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Check</th>
                <th>Why not</th>
              </tr>
            </thead>
            <tbody>
              {CHECKS.filter(
                (c) => !c.admin && (c.state === 'not_configured' || !vendor.selected.includes(c.id)),
              ).map((check) => (
                <tr key={check.id} className="is-dead">
                  <td>{check.name}</td>
                  <td>
                    {check.state === 'not_configured' ? (
                      <>
                        <span className="badge b-unchecked">Not configured</span>{' '}
                        <span className="small muted">No provider is wired up on this platform.</span>
                      </>
                    ) : (
                      <>
                        <span className="badge b-unchecked">Not selected</span>{' '}
                        <span className="small muted">Available, but not chosen for this vendor.</span>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
