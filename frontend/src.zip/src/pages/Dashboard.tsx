import { useNavigate } from 'react-router-dom'

import { Card, Meter, Tile, rupees, toneForScan } from '@/components/ui'
import { useVendorList } from '@/hooks/useVendor'
import { DEFAULT_POLICY, applyPolicy, scoreRisk, scoreScan } from '@/scoring'
import { COMPANY_UNLOCK_PAISA } from '@/catalog/generated'

const STAGE_LABEL: Record<string, string> = {
  intake: 'Intake',
  select: 'Selecting checks',
  running: 'Checks running',
  manual: 'Manual entries',
  scoring: 'Scoring',
  report: 'Report',
  review: 'In review',
  decided: 'Decided',
}

export default function Dashboard() {
  const { vendors, loading } = useVendorList()
  const navigate = useNavigate()

  if (loading) return <p className="muted">Loading vendors…</p>

  const decided = vendors.filter((v) => v.decision)
  const open = vendors.filter((v) => !v.decision)
  const gated = vendors.filter((v) => applyPolicy(scoreScan(v.scan), DEFAULT_POLICY).gated)

  return (
    <div className="stack">
      <div>
        <div className="kicker">Overview</div>
        <h2 className="page-h">Vendor pipeline</h2>
        <p className="page-sub">
          Every vendor under assessment. The system gathers, scores and drafts;
          a named analyst records the binding decision.
        </p>
      </div>

      <div className="grid-4">
        <Tile n={vendors.length} label="Vendors on file" tone="accent" />
        <Tile n={open.length} label="Awaiting a decision" />
        <Tile
          n={gated.length}
          label="Held for coverage"
          note="Reached the threshold on too little evidence"
          tone={gated.length ? 'warn' : 'neutral'}
        />
        <Tile n={decided.length} label="Decided" tone="pass" />
      </div>

      <Card
        title="Vendors"
        subtitle="SCAN verdict and the 0–100 point model, side by side"
        aside={
          <button type="button" className="btn primary" onClick={() => navigate('/vendor/new')}>
            Add a vendor
          </button>
        }
        tight
      >
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Vendor</th>
                <th>Stage</th>
                <th className="num">SCAN</th>
                <th>Coverage</th>
                <th>Verdict</th>
                <th className="num">Risk</th>
                <th>Decision</th>
              </tr>
            </thead>
            <tbody>
              {vendors.map((v) => {
                const scan = scoreScan(v.scan)
                const gate = applyPolicy(scan, DEFAULT_POLICY)
                const risk = scoreRisk(v.checks, v.selected)
                return (
                  <tr
                    key={v.id}
                    onClick={() => navigate(`/vendor/${v.id}/findings`)}
                    style={{ cursor: 'pointer' }}
                  >
                    <td>
                      <div style={{ fontWeight: 550 }}>{v.name}</div>
                      <div className="small muted mono">
                        #{v.id} · {v.cin ?? 'no CIN'}
                      </div>
                    </td>
                    <td>
                      <span className="badge b-neutral">{STAGE_LABEL[v.stage] ?? v.stage}</span>
                    </td>
                    <td className="num nums">
                      {scan.isScored ? `${scan.weighted.toFixed(2)} / ${scan.best.toFixed(2)}` : '—'}
                    </td>
                    <td style={{ minWidth: 130 }}>
                      {scan.isScored ? (
                        <>
                          <div className="small nums">
                            {scan.pct.toFixed(1)}% · {scan.applicable}/{scan.total} params
                          </div>
                          <Meter pct={scan.pct} tone={toneForScan(scan.pct, gate.gated)} />
                        </>
                      ) : (
                        <span className="small muted">Not scored</span>
                      )}
                    </td>
                    <td>
                      {gate.gated ? (
                        <span className="badge b-warn" title={gate.reasons.join(' ')}>
                          Insufficient coverage
                        </span>
                      ) : scan.passed ? (
                        <span className="badge b-pass">Positive</span>
                      ) : scan.isScored ? (
                        <span className="badge b-adverse">Negative</span>
                      ) : (
                        <span className="badge b-unchecked">Not scored</span>
                      )}
                    </td>
                    <td className="num">
                      <span
                        className={`badge b-${
                          risk.band.key === 'approve'
                            ? 'pass'
                            : risk.band.key === 'conditional'
                              ? 'warn'
                              : 'adverse'
                        }`}
                      >
                        {risk.score} {risk.band.label}
                      </span>
                    </td>
                    <td>
                      {v.decision ? (
                        <span
                          className={`badge b-${v.decision === 'Rejected' ? 'adverse' : 'pass'}`}
                        >
                          {v.decision}
                        </span>
                      ) : (
                        <span className="small muted">—</span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid-2">
        <Card title="What a typical audit costs">
          <div className="stack-sm">
            <div className="row-between">
              <span>First audit of a company</span>
              <strong className="nums">{rupees(COMPANY_UNLOCK_PAISA + 500)}</strong>
            </div>
            <div className="row-between">
              <span className="muted">Repeat audit inside the unlock year</span>
              <span className="nums muted">{rupees(500)}</span>
            </div>
            <hr className="divider" />
            <p className="small muted">
              Dominated by the one-time company unlock at {rupees(COMPANY_UNLOCK_PAISA)}. In the
              sample usage data, three unlocks cost more than 1,925 filing downloads — unlocks are
              the cost driver, not call volume.
            </p>
          </div>
        </Card>

        <Card title="Coverage in this build">
          <div className="stack-sm">
            <p className="small muted">
              Nine of the 32 checks have no provider configured, including GST, PAN and all
              sanctions screening. Those gaps appear on every report by name.
            </p>
            <p className="small muted">
              Automation reaches 1.30 of the 4.30 achievable SCAN score — about 34%. The 0.60
              Assessment pillar is almost entirely human, by design.
            </p>
          </div>
        </Card>
      </div>
    </div>
  )
}
