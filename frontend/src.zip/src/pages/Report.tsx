/**
 * Step 8 — the verification report.
 *
 * NO LLM. Fixed sentence templates selected by branching on check status
 * and filled from findings. The same inputs always produce the same text,
 * nothing is invented, and any sentence can be traced to the finding that
 * produced it.
 *
 * Section 6 (coverage) is MANDATORY and never omitted. With nine checks
 * unconfigured, a report that quietly leaves out sanctions screening
 * implies a screening that never happened.
 */

import { useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'

import { CHECKS, MANUAL_TEMPLATES } from '@/catalog/generated'
import { Callout, Card, EmptyState } from '@/components/ui'
import { DEFAULT_POLICY, applyPolicy, scoreRisk, scoreScan, scoreSurveillance } from '@/scoring'
import type { PageProps } from '@/App'
import type { Vendor } from '@/types/domain'

interface Section {
  heading: string
  paragraphs: string[]
}

interface Flag {
  level: 'high' | 'medium' | 'low'
  text: string
}

export function buildReport(vendor: Vendor) {
  const checks = vendor.checks
  const selected = new Set(vendor.selected)
  const ran = (id: string) => selected.has(id) && !!checks[id]
  const get = (id: string) => checks[id] ?? { status: 'skip' as const, value: '—', detail: 'not run' }
  const passed = (id: string) => ran(id) && get(id).status === 'pass'

  const scan = scoreScan(vendor.scan)
  const gate = applyPolicy(scan, DEFAULT_POLICY)
  const risk = scoreRisk(checks, vendor.selected)
  const sv = scoreSurveillance(vendor.surveillance, vendor.surveillanceDone)

  const sections: Section[] = []

  /* 1 · identity and constitution */
  let identity = `${vendor.legalName} was submitted on ${vendor.submitted} for ${vendor.material.toLowerCase()}. `
  if (passed('master')) {
    identity += `MCA records confirm an active registered entity — ${get('master').detail}. `
  } else if (ran('master')) {
    identity += `MCA screening did not return an active company record: ${get('master').detail}. This limits what can be independently corroborated about the entity's standing. `
  } else {
    identity += `Company registry screening was not run for this vendor, so incorporation status is unverified. `
  }
  if (passed('dirs')) identity += `${get('dirs').detail}. `
  sections.push({ heading: 'Identity and constitution', paragraphs: [identity] })

  /* 2 · corporate standing */
  const standing: string[] = []
  if (ran('charges')) {
    standing.push(
      get('charges').status === 'pass'
        ? `No open charges are recorded against the company.`
        : `A charge remains open: ${get('charges').value} — ${get('charges').detail} An unsatisfied charge means a lender still holds security over company assets and should be stated in any onboarding note.`,
    )
  }
  if (ran('filings')) standing.push(`Statutory filings: ${get('filings').detail}.`)
  if (ran('fin')) {
    standing.push(
      `Filed financials (${get('fin').value}) come from the company's own AOC-4 return: ${get('fin').detail}. These are government-filed figures, not estimates.`,
    )
  }
  if (standing.length) {
    sections.push({ heading: 'Corporate standing and financials', paragraphs: [standing.join(' ')] })
  }

  /* 3 · web presence */
  const web: string[] = []
  if (ran('whois')) {
    web.push(
      passed('whois')
        ? `the domain checks out (${get('whois').value.toLowerCase()})`
        : `domain ownership raised a point for attention — ${get('whois').detail}`,
    )
  }
  if (ran('reput')) web.push(`the domain trust score is ${get('reput').value.replace(/^Trust score /, '')}`)
  if (ran('ssl')) web.push(passed('ssl') ? 'SSL is valid' : 'the SSL certificate is not from a trusted authority')
  if (ran('cdx')) web.push(`archive history shows ${get('cdx').value.toLowerCase()}`)
  if (ran('rwhois')) web.push(`the registrant's wider portfolio shows ${get('rwhois').value.toLowerCase()}`)
  if (web.length) {
    let text = `Open-source screening: ${web.join('; ')}. `
    if (ran('cdx') && get('cdx').status !== 'pass') text += `${get('cdx').detail}. `
    if (ran('rwhois')) {
      text += `A varied portfolio under one registrant is consistent with an agency or developer managing client domains; near-identical variations of one brand would instead suggest typosquatting.`
    }
    sections.push({ heading: 'Web presence and domain ownership', paragraphs: [text] })
  }

  /* 4 · internal risk */
  const internal: string[] = []
  if (ran('dup') && get('dup').status !== 'pass') internal.push(`a possible duplicate registration (${get('dup').detail})`)
  if (ran('rp') && get('rp').status !== 'pass') internal.push(`related-party exposure (${get('rp').detail})`)
  if (ran('conflict') && get('conflict').status !== 'pass') internal.push(`an employee conflict of interest (${get('conflict').detail})`)
  sections.push({
    heading: 'Internal risk',
    paragraphs: [
      internal.length
        ? `Checks against the vendor master surfaced ${internal.join(', and ')}. Where this reflects a genuine business relationship it should be recorded as a disclosure rather than treated as disqualifying.`
        : `Checks against the vendor master found no duplicate registration, related-party overlap or employee conflict of interest.`,
    ],
  })

  /* 5 · surveillance */
  sections.push({
    heading: 'Site surveillance',
    paragraphs: [
      sv.done
        ? `Surveillance returned ${sv.verdict}, with ${sv.positives} positives across ${sv.applicable} assessed parameters (${sv.pct}%). ` +
          (sv.gateFailed
            ? `Existence of premises could not be confirmed, which forces the overall field result Negative irrespective of the percentage achieved.`
            : `The 60% field threshold was ${sv.passed ? 'met' : 'not met'}.`)
        : `Site surveillance has not been conducted. SCAN parameter A2 therefore remains Not Applicable and drops out of the weighted calculation, materially reducing coverage of the Assessment pillar — the heaviest at 0.60.`,
    ],
  })

  /* 6 · coverage — MANDATORY, never omitted */
  const notSelected = CHECKS.filter((c) => !c.admin && c.state === 'active' && !selected.has(c.id))
  const hooks = CHECKS.filter((c) => c.state === 'not_configured')
  const skipped = Object.values(checks).filter((c) => c.status === 'skipped_missing_input')
  const coverage =
    `${Object.keys(checks).length} checks were run for this vendor. ` +
    (skipped.length
      ? `${skipped.length} selected ${skipped.length === 1 ? 'check was' : 'checks were'} skipped because a required input was not provided: ${skipped.map((s) => CHECKS.find((c) => c.id === s.checkId)?.name).join(', ')}. `
      : '') +
    (notSelected.length
      ? `${notSelected.length} available checks were not selected: ${notSelected.map((c) => c.name).join(', ')}. `
      : '') +
    (hooks.length
      ? `A further ${hooks.length} checks are not configured on this platform at all: ${hooks.map((c) => c.name).join(', ')}. `
      : '') +
    `Nothing in this report should be read as clearance on any of the above — they were not examined.`
  sections.push({ heading: 'Coverage — what was not checked', paragraphs: [coverage] })

  /* 7 · scoring */
  sections.push({
    heading: 'Scoring',
    paragraphs: [
      `Under the SCAN framework, ${scan.applicable} of ${scan.total} parameters were applicable, producing a weighted score of ${scan.weighted.toFixed(2)} against a best achievable of ${scan.best.toFixed(2)}. The 60% tolerance is ${scan.tolerance60.toFixed(2)}, giving ${scan.pct.toFixed(1)}% achievement. ` +
        (gate.gated
          ? `Under coverage policy ${gate.policyVersion} this does not support a positive recommendation: ${gate.reasons.join(' ')} `
          : '') +
        `The separate 0–100 point model scores ${risk.score}, placing the vendor in the ${risk.band.label} band — ${risk.band.note} ${risk.dead} of its ${risk.ledger.length} rules have no configured data source and did not participate.`,
    ],
  })

  /* 8 · analyst-recorded — kept structurally separate */
  if (vendor.manual.length) {
    sections.push({
      heading: 'Analyst-recorded information (stated, not verified)',
      paragraphs: [
        `The following was recorded by an analyst and has not been independently confirmed by any source. It is presented separately from the findings above for that reason.`,
        ...vendor.manual.map((entry) => {
          const tpl = MANUAL_TEMPLATES.find((t) => t.id === entry.templateId)
          const mapping = tpl?.mapsTo ? (tpl.mapWhen as Record<string, string>)[entry.value] : null
          return (
            `${entry.key}: ${entry.value}. Recorded by ${entry.enteredBy} on ${entry.enteredAt}.` +
            (entry.note ? ` ${entry.note}` : '') +
            (mapping ? ` This entry sets SCAN parameter ${tpl!.mapsTo} to ${mapping}.` : '')
          )
        }),
      ],
    })
  }

  /* flags */
  const flags: Flag[] = []
  for (const [id, result] of Object.entries(checks)) {
    if (!selected.has(id) || result.status !== 'fail') continue
    flags.push({ level: 'high', text: `${CHECKS.find((c) => c.id === id)?.name}: ${result.value} — ${result.detail}` })
  }
  for (const [id, result] of Object.entries(checks)) {
    if (!selected.has(id) || result.status !== 'warn') continue
    flags.push({ level: 'medium', text: `${CHECKS.find((c) => c.id === id)?.name}: ${result.value} — ${result.detail}` })
  }
  if (!sv.done) {
    flags.push({ level: 'medium', text: 'Site surveillance not conducted — Assessment pillar (weight 0.60) largely unevaluated' })
  }
  if (gate.gated) {
    flags.push({ level: 'high', text: `Verdict held for coverage under policy ${gate.policyVersion} — ${gate.reasons.length} condition(s) unmet` })
  }
  if (hooks.length) {
    flags.push({ level: 'low', text: `${hooks.length} checks not configured on this platform, including GST and sanctions screening` })
  }

  return { sections, flags, scan, gate, risk, sv, recommendation: gate.verdict }
}

export default function Report({ vendor, setPrimary }: PageProps) {
  const navigate = useNavigate()
  const report = useMemo(() => buildReport(vendor), [vendor])

  const exportText = () => {
    const lines = [
      `VERIFICATION REPORT — ${vendor.legalName}`,
      `Vendor #${vendor.id} · submitted ${vendor.submitted}`,
      `Generated ${new Date().toISOString().slice(0, 16).replace('T', ' ')}`,
      '',
      'This report is assembled from fixed templates selected by check outcome.',
      'It contains no generated prose. The recommendation is advisory; the binding',
      'decision is recorded by a named analyst.',
      '',
      ...report.sections.flatMap((s) => [
        s.heading.toUpperCase(),
        '─'.repeat(s.heading.length),
        ...s.paragraphs,
        '',
      ]),
      'RISK FLAGS',
      '──────────',
      ...report.flags.map((f) => `[${f.level.toUpperCase()}] ${f.text}`),
      '',
      `RECOMMENDATION: ${report.recommendation}`,
      `Coverage: ${report.scan.coverageNote}`,
      'Recommendation only — not a binding decision.',
    ]
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `VBC-${vendor.id}-report.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  useEffect(() => {
    setPrimary(
      <>
        <button type="button" className="btn" onClick={exportText}>
          Export TXT
        </button>
        <button type="button" className="btn primary" onClick={() => navigate(`/vendor/${vendor.id}/decision`)}>
          Record the decision →
        </button>
      </>,
    )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vendor])

  if (Object.keys(vendor.checks).length === 0) {
    return (
      <EmptyState
        title="Nothing to report on yet"
        body="The report assembles from check findings. Run the checks and it builds itself."
        action={
          <button type="button" className="btn primary" onClick={() => navigate(`/vendor/${vendor.id}/select`)}>
            Choose what to check
          </button>
        }
      />
    )
  }

  return (
    <div className="stack">
      <div>
        <div className="kicker">Step 8 · Output</div>
        <h2 className="page-h">Verification report</h2>
        <p className="page-sub">
          Assembled from fixed templates selected by check outcome. No language model is involved
          anywhere — the same findings always produce the same words.
        </p>
      </div>

      <Callout kind="info" title="Recommendation only">
        This document recommends; it does not decide. The binding approve or reject is recorded by a
        named analyst on the next screen, with reasons.
      </Callout>

      {report.sections.map((section) => (
        <Card key={section.heading} title={section.heading}>
          <div className="stack-sm">
            {section.paragraphs.map((p, i) => (
              <p key={i} style={{ maxWidth: '68ch' }}>
                {p}
              </p>
            ))}
          </div>
        </Card>
      ))}

      <Card title="Risk flags" subtitle="Derived from adverse findings, then from coverage gaps" tight>
        <div className="table-wrap">
          <table className="table">
            <tbody>
              {report.flags.map((flag, i) => (
                <tr key={i}>
                  <td style={{ width: 90 }}>
                    <span
                      className={`badge b-${flag.level === 'high' ? 'adverse' : flag.level === 'medium' ? 'warn' : 'unchecked'}`}
                    >
                      {flag.level}
                    </span>
                  </td>
                  <td>{flag.text}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <div className="row-between">
          <div>
            <div className="kicker">Recommendation</div>
            <h3 style={{ fontSize: 'var(--step-2)' }}>{report.recommendation}</h3>
            <p className="small muted">{report.scan.coverageNote}</p>
          </div>
          <span className={`badge b-${report.gate.gated ? 'warn' : report.scan.passed ? 'pass' : 'adverse'}`}>
            SCAN {report.scan.pct.toFixed(1)}% · Risk {report.risk.score}
          </span>
        </div>
      </Card>
    </div>
  )
}
