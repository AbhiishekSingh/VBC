/**
 * The API contract.
 *
 * Written here first, deliberately: the prototype is the specification for
 * the screens, so the shapes the screens need are known before FastAPI
 * exists. The backend implements this; it does not get to invent a
 * different one.
 */

import type { AuditEntry, ManualEntry, Vendor } from '@/types/domain'

export interface RunChecksResult {
  vendor: Vendor
  ran: number
  skippedMissingInput: string[]
  costPaisa: number
  credits: number
}

export interface DecisionInput {
  decision: 'Approved' | 'Conditional' | 'Rejected'
  remarks: string
  decidedBy: string
  /** Required when the decision contradicts the system recommendation. */
  overrideReason?: string
}

export interface VbcApi {
  listVendors(): Promise<Vendor[]>
  getVendor(id: string): Promise<Vendor | null>
  createVendor(draft: Partial<Vendor>): Promise<Vendor>
  updateVendor(id: string, patch: Partial<Vendor>): Promise<Vendor>

  setSelection(id: string, selected: string[]): Promise<Vendor>
  setCheckInput(id: string, checkId: string, key: string, value: string): Promise<Vendor>
  runChecks(id: string): Promise<RunChecksResult>

  addManualEntry(id: string, entry: Omit<ManualEntry, 'id'>): Promise<Vendor>
  removeManualEntry(id: string, entryId: string): Promise<Vendor>

  setSurveillance(id: string, values: Record<string, string | null>): Promise<Vendor>
  completeSurveillance(id: string): Promise<Vendor>

  setScanRating(id: string, paramId: string, value: string | null): Promise<Vendor>

  recordDecision(id: string, input: DecisionInput): Promise<Vendor>

  listAudit(vendorId?: string): Promise<AuditEntry[]>
  listCostReference(): Promise<
    readonly { group: string; item: string; unit: string; source: string }[]
  >
}
