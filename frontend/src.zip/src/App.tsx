import { Navigate, Route, Routes, useParams } from 'react-router-dom'
import { useState } from 'react'

import { ActionBar, Breadcrumb, Sidebar, StepRail, type FlowRoute, FLOW_LABEL } from '@/components/Layout'
import { ToastProvider } from '@/hooks/useToast'
import { useVendor } from '@/hooks/useVendor'
import type { Vendor } from '@/types/domain'

import Dashboard from '@/pages/Dashboard'
import Submit from '@/pages/Submit'
import Select from '@/pages/Select'
import Findings from '@/pages/Findings'
import Manual from '@/pages/Manual'
import Surveillance from '@/pages/Surveillance'
import Scan from '@/pages/Scan'
import Risk from '@/pages/Risk'
import Report from '@/pages/Report'
import Decision from '@/pages/Decision'
import Outcome from '@/pages/Outcome'
import Audit from '@/pages/Audit'
import Costs from '@/pages/Costs'

export interface PageProps {
  vendor: Vendor
  setVendor: (v: Vendor) => void
  setPrimary: (node: React.ReactNode) => void
}

const FLOW_PAGES: Record<FlowRoute, React.ComponentType<PageProps>> = {
  submit: Submit,
  select: Select,
  findings: Findings,
  manual: Manual,
  surveillance: Surveillance,
  scan: Scan,
  risk: Risk,
  report: Report,
  decision: Decision,
}

/** Wraps a flow page with the furniture every one of them needs. */
function FlowPage() {
  const { id, page } = useParams<{ id: string; page: FlowRoute }>()
  const { vendor, setVendor, loading, error } = useVendor(id)
  const [primary, setPrimary] = useState<React.ReactNode>(null)

  const route = (page ?? 'findings') as FlowRoute
  const Page = FLOW_PAGES[route]

  if (loading) {
    return (
      <main className="content">
        <p className="muted">Loading vendor…</p>
      </main>
    )
  }
  if (error || !vendor) {
    return (
      <main className="content">
        <div className="callout k-adverse">{error ?? 'Vendor not found.'}</div>
      </main>
    )
  }
  if (!Page) return <Navigate to={`/vendor/${vendor.id}/findings`} replace />

  return (
    <>
      <main className="content">
        <Breadcrumb vendor={vendor} current={FLOW_LABEL[route]} />
        <StepRail vendor={vendor} current={route} />
        <Page vendor={vendor} setVendor={setVendor} setPrimary={setPrimary} />
      </main>
      <ActionBar vendor={vendor} current={route} primary={primary} />
    </>
  )
}

/** Governance pages sit outside the flow and share only the shell. */
function StandalonePage({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <>
      <main className="content">
        <Breadcrumb vendor={null} current={title} />
        {children}
      </main>
      <ActionBar vendor={null} current={null} />
    </>
  )
}

function Topbar() {
  return (
    <header className="topbar">
      <div className="row">
        <span className="small muted">
          The system automates the data layer. The analyst retains the decision layer.
        </span>
      </div>
      <div className="row">
        <span className="badge b-neutral">a.mehta · Analyst</span>
      </div>
    </header>
  )
}

export default function App() {
  const { id } = useParams<{ id: string }>()
  const { vendor } = useVendor(id)

  return (
    <ToastProvider>
      <div className="app">
        <Sidebar vendor={vendor} />
        <div className="main">
          <Topbar />
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/vendor/new" element={<NewVendor />} />
            <Route path="/vendor/:id/:page" element={<FlowPage />} />
            <Route
              path="/outcome"
              element={
                <StandalonePage title="Outcome sheet">
                  <Outcome />
                </StandalonePage>
              }
            />
            <Route
              path="/audit"
              element={
                <StandalonePage title="Audit trail">
                  <Audit />
                </StandalonePage>
              }
            />
            <Route
              path="/costs"
              element={
                <StandalonePage title="API cost reference">
                  <Costs />
                </StandalonePage>
              }
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
    </ToastProvider>
  )
}

/** Intake for a vendor that does not exist yet — no id in the URL. */
function NewVendor() {
  const [primary, setPrimary] = useState<React.ReactNode>(null)
  return (
    <>
      <main className="content">
        <Breadcrumb vendor={null} current="Add a vendor" />
        <Submit vendor={null} setVendor={() => {}} setPrimary={setPrimary} />
      </main>
      <ActionBar vendor={null} current="submit" primary={primary} />
    </>
  )
}
