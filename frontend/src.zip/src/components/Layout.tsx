/**
 * The application shell: sidebar, topbar, breadcrumb, step rail, action bar.
 *
 * The vendor is part of the URL (`/vendor/:id/:page`), so a refresh keeps
 * position and any page can be linked to — which matters when an analyst
 * needs to send a colleague straight to a finding.
 */

import { NavLink, useNavigate, useParams } from 'react-router-dom'
import type { ReactNode } from 'react'
import { useEffect } from 'react'

import type { Vendor } from '@/types/domain'
import { API_MODE } from '@/api'

export const FLOW = [
  'submit',
  'select',
  'findings',
  'manual',
  'surveillance',
  'scan',
  'risk',
  'report',
  'decision',
] as const

export type FlowRoute = (typeof FLOW)[number]

export const FLOW_LABEL: Record<FlowRoute, string> = {
  submit: 'Add a vendor',
  select: 'Choose what to check',
  findings: 'Findings',
  manual: 'Manual entries',
  surveillance: 'Site surveillance',
  scan: 'SCAN scoring',
  risk: 'Risk score',
  report: 'Report',
  decision: 'Record the decision',
}

const FLOW_SHORT: Record<FlowRoute, string> = {
  submit: 'Vendor',
  select: 'Checks',
  findings: 'Findings',
  manual: 'Manual',
  surveillance: 'Site visit',
  scan: 'SCAN',
  risk: 'Risk',
  report: 'Report',
  decision: 'Decision',
}

/** Whether a flow step has been completed for this vendor. */
export function stepDone(vendor: Vendor | null, route: FlowRoute): boolean {
  if (!vendor) return false
  switch (route) {
    case 'submit':
      return true
    case 'select':
      return vendor.selected.length > 0
    case 'findings':
      return Object.keys(vendor.checks).length > 0
    case 'manual':
      return vendor.manual.length > 0
    case 'surveillance':
      return vendor.surveillanceDone
    case 'scan':
      return Object.values(vendor.scan).some((v) => v !== null)
    case 'risk':
      return Object.keys(vendor.checks).length > 0
    case 'report':
      return Object.keys(vendor.checks).length > 0
    case 'decision':
      return vendor.decision !== null
  }
}

export function Sidebar({ vendor }: { vendor: Vendor | null }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">VBC</div>
        <div className="brand-sub">Vendor Intelligence</div>
      </div>

      <nav className="nav">
        <NavLink to="/" end className={({ isActive }) => `nav-item${isActive ? ' is-active' : ''}`}>
          <span className="nav-tick" />
          Dashboard
        </NavLink>

        <div className="nav-label">Vendor flow</div>
        {FLOW.map((route) => {
          const done = stepDone(vendor, route)
          if (!vendor) {
            return (
              <span key={route} className="nav-item is-disabled">
                <span className="nav-tick" />
                {FLOW_LABEL[route]}
              </span>
            )
          }
          return (
            <NavLink
              key={route}
              to={`/vendor/${vendor.id}/${route}`}
              className={({ isActive }) => `nav-item${isActive ? ' is-active' : ''}`}
            >
              <span className="nav-tick">{done ? '✓' : ''}</span>
              {FLOW_LABEL[route]}
            </NavLink>
          )
        })}

        <div className="nav-label">Governance</div>
        <NavLink to="/outcome" className={({ isActive }) => `nav-item${isActive ? ' is-active' : ''}`}>
          <span className="nav-tick" />
          Outcome sheet
        </NavLink>
        <NavLink to="/audit" className={({ isActive }) => `nav-item${isActive ? ' is-active' : ''}`}>
          <span className="nav-tick" />
          Audit trail
        </NavLink>
        <NavLink to="/costs" className={({ isActive }) => `nav-item${isActive ? ' is-active' : ''}`}>
          <span className="nav-tick" />
          API cost reference
        </NavLink>
      </nav>

      <div style={{ marginTop: 'auto', padding: '12px 20px', borderTop: '1px solid var(--line-2)' }}>
        <div className="small muted">
          {API_MODE === 'mock' ? 'Mock data — no backend connected' : 'Connected to API'}
        </div>
      </div>
    </aside>
  )
}

export function Breadcrumb({ vendor, current }: { vendor: Vendor | null; current: string }) {
  return (
    <nav className="crumb" aria-label="Breadcrumb">
      <NavLink to="/">Dashboard</NavLink>
      {vendor && (
        <>
          <span className="crumb-sep">›</span>
          <NavLink to={`/vendor/${vendor.id}/findings`}>
            #{vendor.id} {vendor.name}
          </NavLink>
        </>
      )}
      <span className="crumb-sep">›</span>
      <span className="crumb-current">{current}</span>
    </nav>
  )
}

export function StepRail({ vendor, current }: { vendor: Vendor; current: FlowRoute }) {
  const navigate = useNavigate()
  return (
    <div className="rail" role="navigation" aria-label="Flow steps">
      {FLOW.map((route, i) => {
        const isCurrent = route === current
        const done = stepDone(vendor, route)
        return (
          <button
            key={route}
            type="button"
            className={`rail-step${isCurrent ? ' is-current' : ''}${done && !isCurrent ? ' is-done' : ''}`}
            onClick={() => navigate(`/vendor/${vendor.id}/${route}`)}
            aria-current={isCurrent ? 'step' : undefined}
          >
            <span className="rail-n">{done && !isCurrent ? '✓' : i + 1}</span>
            {FLOW_SHORT[route]}
          </button>
        )
      })}
    </div>
  )
}

export function ActionBar({
  vendor,
  current,
  primary,
}: {
  vendor: Vendor | null
  current: FlowRoute | null
  primary?: ReactNode
}) {
  const navigate = useNavigate()
  const index = current ? FLOW.indexOf(current) : -1

  // Alt + arrow walks the flow — analysts move through this many times a day.
  useEffect(() => {
    if (!vendor || index < 0) return
    const onKey = (e: KeyboardEvent) => {
      if (!e.altKey) return
      if (e.key === 'ArrowLeft' && index > 0) {
        navigate(`/vendor/${vendor.id}/${FLOW[index - 1]}`)
      }
      if (e.key === 'ArrowRight' && index < FLOW.length - 1) {
        navigate(`/vendor/${vendor.id}/${FLOW[index + 1]}`)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [vendor, index, navigate])

  return (
    <div className="actionbar">
      <button
        type="button"
        className="btn"
        disabled={index <= 0 || !vendor}
        onClick={() => vendor && navigate(`/vendor/${vendor.id}/${FLOW[index - 1]}`)}
      >
        ← Back
      </button>
      <span className="actionbar-step">
        {index >= 0 ? `Step ${index + 1} of ${FLOW.length}` : ''}
      </span>
      <div className="row">{primary}</div>
    </div>
  )
}

export function useVendorId(): string | undefined {
  return useParams<{ id: string }>().id
}
