"""FileSure (MCA) adapter.

Base: https://api.filesure.in    Header: x-api-key

Every gotcha catalogued in the API reference is handled here, in one place,
so no caller has to remember them:

  * Success wraps in ``data``, errors in ``error``. ``/update/status`` has
    NO ``meta`` object — never assume one exists.
  * Key casing is inconsistent WITHIN a single response: ``directorData``
    is PascalCase (DIN, PAN, FirstName), everything else camelCase, and
    extractions alone are snake_case.
  * Booleans are STRINGS. ``"DirectorDisqualified": "false"`` is truthy in
    Python. Always via ``as_bool``.
  * ``dateOfSatisfaction: null`` means the charge is OPEN — the headline
    audit fact, and the one most likely to be read backwards.
  * Filings ``data`` is a BARE ARRAY, unlike every other endpoint, with
    pagination in ``meta`` — and the sample returns limit 20 when 50 was
    asked for, so read ``meta.limit`` back.
  * Financials are XBRL ``{qname, value, unit}`` triples, not named fields,
    and reaching them is a THREE-step drill-down, not one call.
  * ``unlock`` is GET and POST on one path. GET is free. Always GET first —
    skipping it risks a duplicate ₹220 charge.
  * ``/update`` is async, charges ₹150 at trigger, and must be polled.
  * ``filings/refresh`` can charge ₹5 and return ``fromCache: true``,
    meaning no fresh MCA pull happened.
  * Director update routes are STUBS returning ``{stub: true}`` with 200 OK.
  * A test key returns SANDBOX_ONLY for real DINs and ``sandbox: true`` on
    unlocks — a green sandbox run is not evidence the live path works.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from app.config import Settings
from app.providers.base import (
    HttpProvider,
    NotConfigured,
    ProviderResponse,
    SandboxLimitation,
    Spend,
    as_bool,
    dig,
    parse_ddmmyyyy,
)

logger = logging.getLogger(__name__)

# Unit prices in paisa, derived from /v1/account/usage rather than the
# published rate card — the evaluation report said ₹330 for a company
# unlock and the API reports 22000 paisa.
READ_PAISA = 100          # ₹1     master, resolve, directors, filings, extractions
DOWNLOAD_PAISA = 10       # ₹0.10  per filing document
COMPANY_UNLOCK_PAISA = 22_000   # ₹220
DIRECTOR_UNLOCK_PAISA = 1_000   # ₹10
COMPANY_UPDATE_PAISA = 15_000   # ₹150  async
FILINGS_REFRESH_PAISA = 500     # ₹5    own ~6h cooldown


@dataclass
class UnlockStatus:
    unlocked: bool
    unlocked_at: str | None
    expires_at: str | None
    unlock_price_paisa: int | None
    sandbox: bool = False
    #: Bulk document ZIPs exposed by the unlock job — a cheaper alternative
    #: to per-filing downloads when many documents are needed.
    zip_urls: list[str] = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.zip_urls is None:
            self.zip_urls = []


class FileSureProvider(HttpProvider):
    name = "filesure"

    def __init__(self, settings: Settings | None = None, client=None, spend: Spend | None = None):
        super().__init__(settings, client)
        self.spend = spend or Spend()

    # -----------------------------------------------------------------

    def _require_key(self) -> None:
        if not self.settings.filesure_configured:
            raise NotConfigured(
                "FileSure has no API key configured. Set VBC_FILESURE_API_KEY. "
                "Until then MCA checks report not_configured rather than failing."
            )

    def _call(
        self, method: str, path: str, *, paisa: int = 0, binary: bool = False, **kwargs
    ) -> ProviderResponse:
        self._require_key()
        if paisa:
            self.guard_paid(path, paisa)

        response = self.request(
            method,
            f"{self.settings.filesure_base_url}{path}",
            headers={"x-api-key": self.settings.filesure_api_key},
            binary=binary,
            **kwargs,
        )

        # FileSure reports what it actually charged, and the wallet balance
        # after — cheaper and more accurate than assuming the rate card.
        charged = dig(response.payload, "meta", "priceChargedPaisa", default=None)
        wallet = dig(response.payload, "meta", "walletBalanceAfterPaisa", default=None)
        actual = int(charged) if isinstance(charged, (int, float)) else paisa
        response.paisa_charged = actual
        response.wallet_after = wallet
        if actual or wallet is not None:
            self.spend.record(path, paisa=actual, wallet_after=wallet)
        return response

    @staticmethod
    def _data(response: ProviderResponse) -> Any:
        """Unwrap the ``data`` envelope. Errors wrap in ``error`` instead."""
        payload = response.payload
        if isinstance(payload, dict):
            if "error" in payload and "data" not in payload:
                error = payload["error"]
                message = (
                    f"{error.get('code')}: {error.get('message')}"
                    if isinstance(error, dict)
                    else str(error)
                )
                raise SandboxLimitation(message) if "SANDBOX" in message.upper() else \
                    RuntimeError(f"FileSure error — {message}")
            return payload.get("data", payload)
        return payload

    # =================================================================
    # Companies
    # =================================================================

    def resolve_company(
        self, query: str, *, state: str = "", city: str = "", limit: int = 10
    ) -> list[dict]:
        """Name → CIN. Ranked by ``matchScore``.

        Most candidate fields come back NULL — this returns identity and a
        score, nothing more, so master data still has to be fetched. When
        more than one candidate scores high the AMBIGUITY IS THE FINDING:
        the caller surfaces it rather than auto-picking, because picking the
        wrong company silently audits the wrong business.
        """
        params: dict[str, Any] = {"q": query, "limit": limit}
        if state:
            params["state"] = state
        if city:
            params["city"] = city
        response = self._call("GET", "/v1/companies/resolve", paisa=READ_PAISA, params=params)
        return self._data(response).get("candidates", []) or []

    def company_master(self, cin: str) -> dict:
        """Master data: status, capital, address, directors, charges — one call."""
        response = self._call(
            "GET", f"/v1/companies/{cin}", paisa=READ_PAISA, params={"idType": "cin"}
        )
        return self._data(response)

    def filings(
        self, cin: str, *, form_id: str = "", year: int | None = None,
        limit: int = 50, page: int = 1,
    ) -> tuple[list[dict], dict]:
        """Filing history. Returns (rows, pagination).

        ``data`` is a BARE ARRAY here — unlike every other endpoint — and
        pagination lives in ``meta``. The server may cap ``limit`` below what
        was asked, so the caller gets ``meta`` back to read the real value
        rather than assuming its own request was honoured.
        """
        params: dict[str, Any] = {"limit": limit, "page": page}
        if form_id and form_id != "All forms":
            params["formId"] = form_id
        if year:
            params["year"] = year
        response = self._call(
            "GET", f"/v1/companies/{cin}/filings", paisa=READ_PAISA, params=params
        )
        payload = response.payload
        rows = payload.get("data", []) if isinstance(payload, dict) else []
        meta = payload.get("meta", {}) if isinstance(payload, dict) else {}
        return (rows if isinstance(rows, list) else []), meta

    def download_filing(self, cin: str, filing_id: str) -> bytes:
        """Raw document bytes. Not JSON. Company must be unlocked."""
        response = self._call(
            "GET",
            f"/v1/companies/{cin}/filings/{filing_id}/download",
            paisa=DOWNLOAD_PAISA,
            binary=True,
        )
        return response.content or b""

    def refresh_filings(self, cin: str) -> dict:
        """₹5 filings-only refresh, with its own ~6h cooldown.

        ``fromCache: true`` means you were billed and served the cache — no
        fresh MCA pull happened. The caller must check ``cooldownUntil``
        before calling rather than discovering this after paying.
        """
        response = self._call(
            "POST", f"/v1/companies/{cin}/filings/refresh", paisa=FILINGS_REFRESH_PAISA
        )
        return self._data(response)

    # --- extractions: a THREE-step drill-down ------------------------

    def extraction_form_types(self, cin: str) -> list[str]:
        """Step 1. Absence of AOC-4 means no financials exist at all.

        That is a coverage gap to report, not an error to raise. Note the
        ``?formType=`` query parameter has NO effect — the drill-down is by
        path segment only.
        """
        response = self._call("GET", f"/v1/companies/{cin}/extractions", paisa=READ_PAISA)
        return self._data(response).get("availableFormTypes", []) or []

    def extraction_years(self, cin: str, form_type: str) -> list[int]:
        """Step 2. Years come back DESCENDING, and gaps are a real signal.

        A missing year is a compliance finding — diff against the
        incorporation year rather than taking the max.
        """
        response = self._call(
            "GET", f"/v1/companies/{cin}/extractions/{form_type}", paisa=READ_PAISA
        )
        return self._data(response).get("availableYears", []) or []

    def extraction(
        self, cin: str, form_type: str, year: int, *, scope: str = "standalone"
    ) -> dict:
        """Step 3. XBRL triples. Company must be unlocked.

        ``scope`` materially changes the numbers, so it travels with the
        result and is stated in the report.
        """
        response = self._call(
            "GET",
            f"/v1/companies/{cin}/extractions/{form_type}/{year}",
            paisa=READ_PAISA * 3,
            params={"scope": scope},
        )
        return self._data(response)

    def latest_financials(
        self, cin: str, *, form_type: str = "AOC-4", year: int | None = None,
        scope: str = "standalone",
    ) -> dict | None:
        """Walk all three extraction steps and return the newest filing.

        Returns None when the form type is not available at all — which is a
        gap to report, not a failure.
        """
        available = self.extraction_form_types(cin)
        if form_type not in available:
            logger.info("%s: %s not among available form types %s", cin, form_type, available)
            return None

        years = self.extraction_years(cin, form_type)
        if not years:
            return None

        target = year if year in years else max(years)
        data = self.extraction(cin, form_type, target, scope=scope)
        data["_requested_year"] = year
        data["_resolved_year"] = target
        data["_available_years"] = years
        data["_year_gaps"] = self.year_gaps(years)
        return data

    @staticmethod
    def year_gaps(years: list[int]) -> list[int]:
        """Missing years between the earliest and latest filed.

        A gap is a compliance signal, not an error — a company that filed in
        2022 and 2024 but not 2023 has a story worth asking about.
        """
        if len(years) < 2:
            return []
        ordered = sorted(years)
        return [y for y in range(ordered[0], ordered[-1] + 1) if y not in set(ordered)]

    # --- unlock: GET is free, POST costs ₹220 ------------------------

    def unlock_status(self, cin: str) -> UnlockStatus:
        """FREE status check. ALWAYS call this before POSTing an unlock."""
        response = self._call("GET", f"/v1/companies/{cin}/unlock")
        data = self._data(response)

        zips: list[str] = []
        stages = dig(data, "job", "processingStages", default={}) or {}
        for stage in stages.values() if isinstance(stages, dict) else []:
            if isinstance(stage, dict):
                for zf in stage.get("zipFiles", []) or []:
                    if isinstance(zf, dict) and zf.get("blob_url"):
                        zips.append(zf["blob_url"])

        return UnlockStatus(
            unlocked=as_bool(data.get("unlocked")),
            unlocked_at=data.get("unlockedAt"),
            expires_at=data.get("expiresAt"),
            unlock_price_paisa=data.get("unlockPrice"),
            sandbox=as_bool(data.get("sandbox")),
            zip_urls=zips,
        )

    def unlock_company(self, cin: str) -> UnlockStatus:
        """₹220, once per company per year. Never call without the GET first.

        A ``sandbox: true`` response has null timestamps and no job — the
        call succeeded but nothing was really unlocked. Treated as a sandbox
        limitation rather than a success, so test runs cannot be mistaken
        for proof the live path works.
        """
        response = self._call(
            "POST", f"/v1/companies/{cin}/unlock", paisa=COMPANY_UNLOCK_PAISA
        )
        data = self._data(response)
        status = UnlockStatus(
            unlocked=as_bool(data.get("unlocked")),
            unlocked_at=data.get("unlockedAt"),
            expires_at=data.get("expiresAt"),
            unlock_price_paisa=data.get("unlockPrice"),
            sandbox=as_bool(data.get("sandbox")),
        )
        if status.sandbox:
            logger.warning(
                "%s: unlock returned sandbox:true — no real unlock occurred", cin
            )
        return status

    def ensure_unlocked(self, cin: str) -> tuple[UnlockStatus, bool]:
        """GET first; only POST when genuinely needed. Returns (status, paid).

        This is the single most valuable cost control in the integration.
        Three unlocks cost more than 1,925 filing downloads, and the check
        that avoids a duplicate is free.
        """
        status = self.unlock_status(cin)
        if status.unlocked and status.expires_at:
            return status, False
        if COMPANY_UNLOCK_PAISA > self.settings.company_unlock_paisa_cap:
            raise RuntimeError(
                f"Company unlock costs {COMPANY_UNLOCK_PAISA} paisa, above the "
                f"configured cap of {self.settings.company_unlock_paisa_cap}."
            )
        return self.unlock_company(cin), True

    # --- async company update ---------------------------------------

    def trigger_update(self, cin: str) -> dict:
        """₹150, charged at trigger. Returns immediately with status pending.

        The data is NOT fresh when this returns. Poll before reading master
        data, or you read the stale values you just paid to replace.
        """
        response = self._call(
            "POST", f"/v1/companies/{cin}/update", paisa=COMPANY_UPDATE_PAISA
        )
        return self._data(response)

    def update_status(self, cin: str) -> dict:
        """Free to poll. NOTE: this response has no ``meta`` object."""
        response = self._call("GET", f"/v1/companies/{cin}/update/status")
        return self._data(response)

    # =================================================================
    # Directors
    # =================================================================

    def resolve_director(self, query: str, *, limit: int = 10) -> list[dict]:
        """Name → DIN.

        ``totalDirectorshipCount`` is a free red-flag metric: an unusually
        high count is the classic mass-director / dummy-director pattern.
        """
        response = self._call(
            "GET", "/v1/directors/resolve", paisa=READ_PAISA,
            params={"q": query, "limit": limit},
        )
        return self._data(response).get("candidates", []) or []

    def director_profile(self, din: str) -> dict:
        """Full directorship history. ``cessationDate: null`` = still serving.

        Dates here are ISO while company master uses DD/MM/YYYY. Also
        returns gender, nationality and qualification — decide deliberately
        whether those belong in a client-facing report.
        """
        response = self._call("GET", f"/v1/directors/{din}", paisa=READ_PAISA)
        return self._data(response)

    def director_contact(self, din: str) -> dict:
        """Mobile is returned MASKED. Requires a ₹10 director unlock."""
        response = self._call("GET", f"/v1/directors/{din}/contact", paisa=READ_PAISA)
        return self._data(response)

    def director_unlock_status(self, din: str) -> dict:
        response = self._call("GET", f"/v1/directors/{din}/unlock")
        return self._data(response)

    def ensure_director_unlocked(self, din: str) -> tuple[dict, bool]:
        status = self.director_unlock_status(din)
        if as_bool(status.get("unlocked")):
            return status, False
        response = self._call(
            "POST", f"/v1/directors/{din}/unlock", paisa=DIRECTOR_UNLOCK_PAISA
        )
        return self._data(response), True

    # NOTE: director update endpoints are deliberately NOT wrapped. Both
    # return {"stub": true} with HTTP 200, so any wrapper would report a
    # successful no-op. Refresh director data via the company update.

    # =================================================================
    # Account
    # =================================================================

    def account_usage(self) -> dict:
        """Wallet balance and 30-day spend by endpoint. Free.

        The only place real unit prices can be derived — divide spendPaisa
        by calls per endpoint.
        """
        response = self._call("GET", "/v1/account/usage")
        return self._data(response)


# =====================================================================
# Normalisers — payload to finding
# =====================================================================


def normalise_master(data: dict) -> dict:
    """Flatten master data into the facts the scoring engine needs."""
    company = dig(data, "masterData", "companyData", default={}) or {}
    addresses = company.get("MCAMDSCompanyAddress", []) or []
    registered = next(
        (a for a in addresses if a.get("addressType") == "Registered Address"),
        addresses[0] if addresses else {},
    )
    return {
        "cin": data.get("cin"),
        "company": data.get("company"),
        "status": company.get("companyStatus"),
        "class_of_company": company.get("classOfCompany"),
        "company_type": company.get("companyType"),
        "listed": company.get("whetherListedOrNot"),
        "incorporated_on": parse_ddmmyyyy(company.get("dateOfIncorporation")),
        "authorised_capital": company.get("authorisedCapital"),
        "paidup_capital": company.get("paidupCapital"),
        "active_compliance": company.get("activeCompliance"),
        "registered_address": registered.get("streetAddress"),
        "nic_division": dig(data, "masterData", "commonData", "mainDivisionDescription"),
        # A non-empty history means the company was renamed or re-registered
        # — a finding in itself, not noise.
        "cin_history": data.get("cinHistory", []) or [],
        "name_history": data.get("nameHistory", []) or [],
    }


def normalise_directors(data: dict) -> list[dict]:
    """directorData is PascalCase and its booleans are strings."""
    rows = dig(data, "masterData", "directorData", default=[]) or []
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        first = (row.get("FirstName") or "").strip()
        last = (row.get("LastName") or "").strip()
        out.append(
            {
                "din": row.get("DIN"),
                "pan": row.get("PAN"),
                "name": " ".join(p for p in (first, last) if p),
                "appointed_on": parse_ddmmyyyy(row.get("dateOfAppointment")),
                # "false" is a truthy string — this must go through as_bool.
                "disqualified": as_bool(row.get("DirectorDisqualified")),
                "roles": row.get("MCAUserRole", []) or [],
            }
        )
    return out


def normalise_charges(data: dict) -> dict:
    """dateOfSatisfaction is null for an OPEN charge — the headline fact."""
    rows = dig(data, "masterData", "indexChargesData", default=[]) or []
    open_charges, closed_charges = [], []
    for row in rows:
        if not isinstance(row, dict):
            continue
        charge = {
            "charge_id": row.get("chargeId"),
            "holder": row.get("chName"),
            "amount": row.get("chargeAmount"),
            "created_on": parse_ddmmyyyy(row.get("dateOfCreation")),
            "satisfied_on": parse_ddmmyyyy(row.get("dateOfSatisfaction")),
        }
        (open_charges if row.get("dateOfSatisfaction") is None else closed_charges).append(charge)
    return {
        "open": open_charges,
        "closed": closed_charges,
        "open_total": sum(c["amount"] or 0 for c in open_charges),
    }


#: XBRL qname → human label. Never assume a qname is present.
XBRL_LABELS: dict[str, str] = {
    "in-ca:RevenueFromOperations": "Revenue from operations",
    "in-ca:OtherIncome": "Other income",
    "in-ca:ProfitBeforeTax": "Profit before tax",
    "in-ca:ProfitLossForPeriod": "Profit for the period",
    "in-ca:Equity": "Equity / net worth",
    "in-ca:Assets": "Total assets",
    "in-ca:Liabilities": "Total liabilities",
    "in-ca:CashFlowsFromUsedInOperatingActivities": "Operating cash flow",
    "in-ca:CashFlowsFromUsedInInvestingActivities": "Investing cash flow",
    "in-ca:CashFlowsFromUsedInFinancingActivities": "Financing cash flow",
}


def normalise_financials(data: dict) -> dict:
    """XBRL triples into named figures. Values are raw rupees.

    This endpoint alone uses snake_case. A qname that is not present is
    simply absent from the result — never defaulted to zero, which would
    turn missing data into a reported figure of nil.
    """
    figures: dict[str, dict] = {}
    for section in ("balance_sheet", "profit_and_loss", "cash_flow"):
        for triple in data.get(section, []) or []:
            if not isinstance(triple, dict):
                continue
            qname = triple.get("qname")
            if not qname:
                continue
            figures[qname] = {
                "label": XBRL_LABELS.get(qname, qname.replace("in-ca:", "")),
                "value": triple.get("value"),
                "unit": triple.get("unit", "INR"),
                "section": section,
            }

    revenue = dig(figures, "in-ca:RevenueFromOperations", "value")
    equity = dig(figures, "in-ca:Equity", "value")
    return {
        # scope is stated because standalone vs consolidated changes the
        # numbers materially.
        "scope": data.get("filing_scope"),
        "period_start": data.get("period_start"),
        "period_end": data.get("period_end"),
        "taxonomy": data.get("taxonomy_id"),
        "filed_on": parse_ddmmyyyy(dig(data, "metadata", "source", "dateOfFiling")),
        "year": data.get("_resolved_year") or dig(data, "metadata", "source", "year"),
        "available_years": data.get("_available_years", []),
        "year_gaps": data.get("_year_gaps", []),
        "figures": figures,
        "revenue": revenue,
        "net_worth": equity,
        "positive_net_worth": (equity is not None and equity > 0),
    }
